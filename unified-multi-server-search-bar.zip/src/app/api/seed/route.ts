import { NextResponse } from "next/server";
import { db } from "@/db";
import { servers, searchableItems } from "@/db/schema";

export async function POST() {
  try {
    // Clear existing data
    await db.delete(searchableItems);
    await db.delete(servers);

    // ── Insert 6 Servers ──────────────────────────────────────────────────────
    const insertedServers = await db
      .insert(servers)
      .values([
        {
          name: "web-prod-01",
          hostname: "web-prod-01.internal",
          ipAddress: "10.0.1.10",
          location: "US-East (Virginia)",
          status: "online",
          os: "Ubuntu 22.04 LTS",
          tags: ["production", "web", "nginx"],
        },
        {
          name: "web-prod-02",
          hostname: "web-prod-02.internal",
          ipAddress: "10.0.1.11",
          location: "US-East (Virginia)",
          status: "online",
          os: "Ubuntu 22.04 LTS",
          tags: ["production", "web", "nginx"],
        },
        {
          name: "db-master-01",
          hostname: "db-master-01.internal",
          ipAddress: "10.0.2.10",
          location: "US-West (Oregon)",
          status: "online",
          os: "Debian 12",
          tags: ["production", "database", "postgresql"],
        },
        {
          name: "app-staging-01",
          hostname: "app-staging-01.internal",
          ipAddress: "10.0.3.10",
          location: "EU-West (Ireland)",
          status: "maintenance",
          os: "Ubuntu 24.04 LTS",
          tags: ["staging", "application", "docker"],
        },
        {
          name: "worker-queue-01",
          hostname: "worker-queue-01.internal",
          ipAddress: "10.0.4.10",
          location: "US-Central (Chicago)",
          status: "online",
          os: "Amazon Linux 2023",
          tags: ["production", "worker", "redis", "rabbitmq"],
        },
        {
          name: "monitor-01",
          hostname: "monitor-01.internal",
          ipAddress: "10.0.5.10",
          location: "US-East (Virginia)",
          status: "degraded",
          os: "Ubuntu 22.04 LTS",
          tags: ["monitoring", "grafana", "prometheus"],
        },
      ])
      .returning();

    const serverMap = Object.fromEntries(
      insertedServers.map((s) => [s.name, s.id])
    );

    // ── Insert Searchable Items ───────────────────────────────────────────────

    const now = new Date();
    const hour = (h: number) => new Date(now.getTime() - h * 3600000);

    const items = [
      // === LOGS ===
      {
        serverId: serverMap["web-prod-01"],
        category: "log" as const,
        title: "Nginx access log - 502 Bad Gateway spike",
        content:
          "Multiple 502 Bad Gateway errors detected in nginx access.log between 14:00-14:30 UTC. Upstream connection refused from app server pool. Total affected requests: 2,847.",
        status: "error" as const,
        severity: "critical",
        source: "/var/log/nginx/access.log",
        tags: ["nginx", "502", "gateway", "errors"],
        metadata: JSON.stringify({
          lines: "102847-103102",
          format: "combined",
        }),
        createdAt: hour(2),
      },
      {
        serverId: serverMap["web-prod-02"],
        category: "log" as const,
        title: "Nginx error log - SSL handshake failures",
        content:
          "SSL handshake errors from expired client certificates. Affecting /api/v2/webhook endpoints. Certificate CN=microservice-client-03 expired 2024-01-15.",
        status: "warning" as const,
        severity: "medium",
        source: "/var/log/nginx/error.log",
        tags: ["ssl", "tls", "certificate", "handshake"],
        metadata: JSON.stringify({ lines: "45023-45089" }),
        createdAt: hour(5),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "log" as const,
        title: "PostgreSQL slow query log - queries > 5s",
        content:
          "17 slow queries detected in the last hour. Most affected table: 'orders' with full table scans on 'customer_id' column. Recommend adding index on orders(customer_id) WHERE status = 'pending'.",
        status: "warning" as const,
        severity: "high",
        source: "/var/log/postgresql/slow-queries.log",
        tags: ["postgresql", "slow-query", "performance", "database"],
        metadata: JSON.stringify({ queryCount: 17, maxDuration: "12.3s" }),
        createdAt: hour(1),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "log" as const,
        title: "RabbitMQ consumer crash - OOM killed",
        content:
          "Worker process PID 28847 killed by OOM killer while processing batch job #94721. Memory usage exceeded 4GB limit. Queue 'email-notifications' backed up to 50,000 messages.",
        status: "error" as const,
        severity: "critical",
        source: "/var/log/rabbitmq/crash.log",
        tags: ["rabbitmq", "oom", "crash", "memory"],
        metadata: JSON.stringify({ pid: 28847, jobId: 94721 }),
        createdAt: hour(0.5),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "log" as const,
        title: "Prometheus scrape timeout errors",
        content:
          "Prometheus unable to scrape targets 'web-prod-01:9090' and 'web-prod-02:9090'. Scrape timeout of 15s exceeded. Last successful scrape: 2 hours ago.",
        status: "error" as const,
        severity: "high",
        source: "/var/log/prometheus/prometheus.log",
        tags: ["prometheus", "scrape", "timeout", "monitoring"],
        metadata: JSON.stringify({ targets: 2, timeout: "15s" }),
        createdAt: hour(2),
      },
      {
        serverId: serverMap["app-staging-01"],
        category: "log" as const,
        title: "Application startup log - deployment v2.4.1",
        content:
          "Application v2.4.1 starting in staging environment. Connected to database, Redis cache initialized, 4 worker threads spawned. Health check endpoint /health responding on port 8080.",
        status: "active" as const,
        severity: "info",
        source: "/var/log/app/startup.log",
        tags: ["startup", "deployment", "v2.4.1"],
        metadata: JSON.stringify({ version: "2.4.1", port: 8080 }),
        createdAt: hour(8),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "log" as const,
        title: "PostgreSQL replication lag warning",
        content:
          "Streaming replication lag to db-replica-01 exceeded 30 seconds. Current lag: 47 seconds. WAL sender process healthy but network throughput degraded.",
        status: "warning" as const,
        severity: "high",
        source: "/var/log/postgresql/replication.log",
        tags: ["postgresql", "replication", "lag", "wal"],
        metadata: JSON.stringify({ lagSeconds: 47, replica: "db-replica-01" }),
        createdAt: hour(3),
      },
      {
        serverId: serverMap["web-prod-01"],
        category: "log" as const,
        title: "Syslog - disk space warning on /var",
        content:
          "Filesystem /var is at 89% capacity. Only 2.3GB remaining. Log rotation may be needed. Largest files: /var/log/nginx/access.log (4.1GB), /var/log/syslog (1.8GB).",
        status: "warning" as const,
        severity: "medium",
        source: "/var/log/syslog",
        tags: ["disk", "space", "filesystem", "syslog"],
        metadata: JSON.stringify({ usagePercent: 89, remainingGB: 2.3 }),
        createdAt: hour(6),
      },

      // === CONTAINERS ===
      {
        serverId: serverMap["app-staging-01"],
        category: "container" as const,
        title: "app-backend-staging",
        content:
          "Docker container running Node.js API server. Image: registry.internal/app-backend:v2.4.1. Ports: 8080->3000. CPU: 12%, Memory: 512MB/2GB. Running for 8 hours.",
        status: "active" as const,
        severity: null,
        source: "docker",
        tags: ["docker", "nodejs", "api", "staging"],
        metadata: JSON.stringify({
          image: "registry.internal/app-backend:v2.4.1",
          ports: "8080:3000",
          uptime: "8h",
        }),
        createdAt: hour(8),
      },
      {
        serverId: serverMap["app-staging-01"],
        category: "container" as const,
        title: "redis-cache-staging",
        content:
          "Redis 7.2 container for session caching. Image: redis:7.2-alpine. Memory: 256MB allocated, 67% used. Connected clients: 12. Hit rate: 94.3%.",
        status: "active" as const,
        severity: null,
        source: "docker",
        tags: ["docker", "redis", "cache", "staging"],
        metadata: JSON.stringify({
          image: "redis:7.2-alpine",
          hitRate: "94.3%",
          memory: "256MB",
        }),
        createdAt: hour(8),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "container" as const,
        title: "rabbitmq-broker",
        content:
          "RabbitMQ 3.12 message broker container. Image: rabbitmq:3.12-management. Queues: 23, Messages ready: 50,847. Memory high watermark reached.",
        status: "warning" as const,
        severity: "high",
        source: "docker",
        tags: ["docker", "rabbitmq", "queue", "broker"],
        metadata: JSON.stringify({
          image: "rabbitmq:3.12-management",
          queues: 23,
          messagesReady: 50847,
        }),
        createdAt: hour(0.5),
      },
      {
        serverId: serverMap["app-staging-01"],
        category: "container" as const,
        title: "app-frontend-staging",
        content:
          "Nginx serving static React frontend build. Image: registry.internal/app-frontend:v2.4.1. Ports: 3000->80. Serving 45 assets, gzip enabled.",
        status: "active" as const,
        severity: null,
        source: "docker",
        tags: ["docker", "nginx", "frontend", "react"],
        metadata: JSON.stringify({
          image: "registry.internal/app-frontend:v2.4.1",
          ports: "3000:80",
        }),
        createdAt: hour(8),
      },
      {
        serverId: serverMap["web-prod-01"],
        category: "container" as const,
        title: "certbot-auto-renew",
        content:
          "Certbot certificate auto-renewal container. Next renewal check: 12 days. Current certificates valid for *.example.com. Last renewal: 28 days ago.",
        status: "active" as const,
        severity: null,
        source: "docker",
        tags: ["docker", "certbot", "ssl", "letsencrypt"],
        metadata: JSON.stringify({
          nextRenewal: "12 days",
          domain: "*.example.com",
        }),
        createdAt: hour(168),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "container" as const,
        title: "grafana-dashboard",
        content:
          "Grafana 10.2 visualization dashboard. Image: grafana/grafana:10.2.0. Dashboards: 14, Data sources: 3 (Prometheus, Loki, PostgreSQL). Plugins: 5.",
        status: "active" as const,
        severity: null,
        source: "docker",
        tags: ["docker", "grafana", "monitoring", "dashboard"],
        metadata: JSON.stringify({
          image: "grafana/grafana:10.2.0",
          dashboards: 14,
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "container" as const,
        title: "loki-log-aggregator",
        content:
          "Grafana Loki log aggregation system. Image: grafana/loki:2.9.0. Ingesting logs from all 6 servers. Storage: 45GB used, retention: 30 days.",
        status: "active" as const,
        severity: null,
        source: "docker",
        tags: ["docker", "loki", "logs", "aggregation"],
        metadata: JSON.stringify({
          image: "grafana/loki:2.9.0",
          storageGB: 45,
          retention: "30 days",
        }),
        createdAt: hour(720),
      },

      // === APPS ===
      {
        serverId: serverMap["web-prod-01"],
        category: "app" as const,
        title: "E-Commerce Platform - Main API",
        content:
          "Primary REST API serving 12,000 requests/min. Node.js 20.x with Express. Endpoints: 147. Response time p95: 230ms. Uptime: 99.97% (30 days).",
        status: "active" as const,
        severity: null,
        source: "pm2",
        tags: ["api", "ecommerce", "production", "nodejs"],
        metadata: JSON.stringify({
          requestsPerMin: 12000,
          endpoints: 147,
          p95: "230ms",
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["web-prod-02"],
        category: "app" as const,
        title: "E-Commerce Platform - Secondary API",
        content:
          "Load-balanced REST API instance. Node.js 20.x with Express. Handling 40% of traffic. Currently receiving canary traffic for v2.4.1 deployment test.",
        status: "active" as const,
        severity: null,
        source: "pm2",
        tags: ["api", "ecommerce", "production", "canary"],
        metadata: JSON.stringify({
          trafficPercent: 40,
          canaryVersion: "v2.4.1",
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["app-staging-01"],
        category: "app" as const,
        title: "E-Commerce Platform - Staging",
        content:
          "Staging environment for E-Commerce Platform v2.4.1. New features: bulk order processing, enhanced search, payment retry logic. All 847 tests passing.",
        status: "active" as const,
        severity: null,
        source: "pm2",
        tags: ["staging", "ecommerce", "v2.4.1"],
        metadata: JSON.stringify({
          version: "2.4.1",
          testsPassing: 847,
        }),
        createdAt: hour(8),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "app" as const,
        title: "Background Job Processor",
        content:
          "Bull queue processor handling email, PDF generation, image processing, and webhook delivery. Workers: 8 (4 active, 4 idle). Processing 2,400 jobs/hour.",
        status: "active" as const,
        severity: null,
        source: "pm2",
        tags: ["worker", "jobs", "queue", "background"],
        metadata: JSON.stringify({ workers: 8, jobsPerHour: 2400 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "app" as const,
        title: "Prometheus Monitoring Server",
        content:
          "Prometheus 2.48 metrics collection. Scrape interval: 15s. Targets: 18 (6 servers x 3 exporters). Alert rules: 42. Active alerts: 3.",
        status: "warning" as const,
        severity: "medium",
        source: "systemd",
        tags: ["prometheus", "monitoring", "metrics"],
        metadata: JSON.stringify({ targets: 18, alertRules: 42, activeAlerts: 3 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "app" as const,
        title: "pgBouncer Connection Pooler",
        content:
          "PgBouncer 1.21 connection pooler in front of PostgreSQL. Pool mode: transaction. Active connections: 45/200. Avg query time: 4.2ms.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["pgbouncer", "connection-pool", "postgresql"],
        metadata: JSON.stringify({
          activeConnections: 45,
          maxConnections: 200,
          avgQueryTime: "4.2ms",
        }),
        createdAt: hour(720),
      },

      // === PROGRAMS ===
      {
        serverId: serverMap["web-prod-01"],
        category: "program" as const,
        title: "Node.js v20.11.0 Runtime",
        content:
          "Node.js LTS runtime powering the E-Commerce API. V8 engine v11.3. Built-in TLS, HTTP/2 support. Active handles: 1,247. Event loop lag: 2ms avg.",
        status: "active" as const,
        severity: null,
        source: "process",
        tags: ["nodejs", "runtime", "javascript"],
        metadata: JSON.stringify({ version: "20.11.0", v8: "11.3" }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "program" as const,
        title: "PostgreSQL 16.1 Database Server",
        content:
          "PostgreSQL 16.1 database with 342 databases, 15,847 tables. Shared buffers: 4GB, Work mem: 256MB. Active connections: 45/200. Transactions/sec: 3,200.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["postgresql", "database", "rdbms"],
        metadata: JSON.stringify({
          version: "16.1",
          databases: 342,
          tables: 15847,
          tps: 3200,
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["web-prod-01"],
        category: "program" as const,
        title: "Nginx 1.24.0 Web Server",
        content:
          "Nginx reverse proxy and static file server. Worker processes: 4. SSL termination enabled. HTTP/2 enabled. Gzip compression active. Rate limiting: 100 req/s per IP.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["nginx", "webserver", "reverse-proxy"],
        metadata: JSON.stringify({ version: "1.24.0", workers: 4 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "program" as const,
        title: "Redis 7.2.3 Cache Server",
        content:
          "Redis in-memory data store for caching and session management. Memory: 2GB allocated, 1.3GB used. Keys: 847,293. Hit rate: 96.7%. Eviction policy: allkeys-lru.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["redis", "cache", "sessions"],
        metadata: JSON.stringify({
          version: "7.2.3",
          keys: 847293,
          hitRate: "96.7%",
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "program" as const,
        title: "Alertmanager 0.26.0",
        content:
          "Alertmanager handling alert routing and notification. Receivers: 8 (Slack, PagerDuty, Email). Silenced alerts: 5. Active firing: 3. Inhibition rules: 12.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["alertmanager", "alerts", "notifications"],
        metadata: JSON.stringify({ receivers: 8, silenced: 5, firing: 3 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["web-prod-02"],
        category: "program" as const,
        title: "HAProxy 2.8 Load Balancer",
        content:
          "HAProxy load balancer distributing traffic between web-prod-01 and web-prod-02. Algorithm: round-robin. Health checks every 5s. Backend servers: 2/2 UP.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["haproxy", "load-balancer", "proxy"],
        metadata: JSON.stringify({
          version: "2.8",
          backends: "2/2 UP",
          algorithm: "round-robin",
        }),
        createdAt: hour(720),
      },

      // === DOCUMENTS ===
      {
        serverId: serverMap["web-prod-01"],
        category: "document" as const,
        title: "API Documentation v2.4 - REST Endpoints",
        content:
          "Complete API reference documentation for E-Commerce Platform v2.4. Covers 147 endpoints across 12 resource groups: products, orders, users, payments, shipping, inventory, reviews, cart, wishlist, search, webhooks, admin.",
        status: "active" as const,
        severity: null,
        source: "/opt/docs/api-reference.md",
        tags: ["api", "documentation", "rest", "openapi"],
        metadata: JSON.stringify({ format: "markdown", endpoints: 147 }),
        createdAt: hour(168),
      },
      {
        serverId: serverMap["app-staging-01"],
        category: "document" as const,
        title: "Deployment Runbook - v2.4.1",
        content:
          "Step-by-step deployment runbook for E-Commerce Platform v2.4.1. Includes pre-deployment checklist, database migration steps, canary deployment procedure, rollback plan, and post-deployment verification.",
        status: "active" as const,
        severity: null,
        source: "/opt/docs/runbook-v2.4.1.md",
        tags: ["runbook", "deployment", "operations"],
        metadata: JSON.stringify({ format: "markdown", steps: 24 }),
        createdAt: hour(24),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "document" as const,
        title: "Database Schema Documentation",
        content:
          "PostgreSQL database schema documentation. 15,847 tables across 12 schemas. Includes ER diagrams, index definitions, constraint descriptions, and query optimization notes. Last updated: 2024-01-10.",
        status: "active" as const,
        severity: null,
        source: "/opt/docs/db-schema.md",
        tags: ["database", "schema", "documentation"],
        metadata: JSON.stringify({ tables: 15847, schemas: 12 }),
        createdAt: hour(336),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "document" as const,
        title: "Incident Response Playbook",
        content:
          "Incident response procedures for common scenarios: database failover, DDoS mitigation, SSL certificate expiry, disk space exhaustion, memory leak diagnosis, and cascading failure recovery.",
        status: "active" as const,
        severity: null,
        source: "/opt/docs/incident-response.md",
        tags: ["incident", "response", "playbook", "sre"],
        metadata: JSON.stringify({ procedures: 6 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["web-prod-01"],
        category: "document" as const,
        title: "Nginx Configuration Guide",
        content:
          "Nginx configuration reference for production web servers. Includes SSL/TLS settings, rate limiting rules, proxy configurations, caching policies, and security headers. Certbot auto-renewal setup included.",
        status: "active" as const,
        severity: null,
        source: "/opt/docs/nginx-config.md",
        tags: ["nginx", "configuration", "guide"],
        metadata: JSON.stringify({ sections: 8 }),
        createdAt: hour(720),
      },

      // === CONFIG ===
      {
        serverId: serverMap["web-prod-01"],
        category: "config" as const,
        title: "Nginx main.conf - Production Configuration",
        content:
          "Worker processes: 4, worker_connections: 4096. SSL protocols: TLSv1.2 TLSv1.3. Rate limiting zone: 10m, rate=100r/s. Proxy buffer: 16k. Gzip: on, types: text/plain application/json.",
        status: "active" as const,
        severity: null,
        source: "/etc/nginx/nginx.conf",
        tags: ["nginx", "config", "production"],
        metadata: JSON.stringify({ format: "nginx-conf" }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "config" as const,
        title: "PostgreSQL postgresql.conf - Master Config",
        content:
          "shared_buffers=4GB, effective_cache_size=12GB, work_mem=256MB, maintenance_work_mem=1GB. max_connections=200. wal_level=replica. max_wal_senders=5. archive_mode=on.",
        status: "active" as const,
        severity: null,
        source: "/etc/postgresql/16/main/postgresql.conf",
        tags: ["postgresql", "config", "performance"],
        metadata: JSON.stringify({ format: "postgresql-conf" }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "config" as const,
        title: "RabbitMQ rabbitmq.conf",
        content:
          "vm_memory_high_watermark: 0.7, disk_free_limit: 2GB. Queue max_length: 100000. Consumer_timeout: 1800000 (30min). Management UI port: 15672. Clustering: disabled.",
        status: "active" as const,
        severity: null,
        source: "/etc/rabbitmq/rabbitmq.conf",
        tags: ["rabbitmq", "config", "messaging"],
        metadata: JSON.stringify({ format: "rabbitmq-conf" }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "config" as const,
        title: "Prometheus prometheus.yml",
        content:
          "Scrape interval: 15s, evaluation interval: 15s. Scrape configs: 6 (node_exporter, postgres_exporter, nginx_exporter, redis_exporter, app_metrics, blackbox). Alert rules path: /etc/prometheus/rules/*.yml.",
        status: "active" as const,
        severity: null,
        source: "/etc/prometheus/prometheus.yml",
        tags: ["prometheus", "config", "scraping"],
        metadata: JSON.stringify({ scrapeConfigs: 6 }),
        createdAt: hour(720),
      },

      // === METRICS ===
      {
        serverId: serverMap["web-prod-01"],
        category: "metric" as const,
        title: "HTTP Request Rate - 12,000 req/min",
        content:
          "Current HTTP request rate: 12,000 requests/minute. Peak today: 18,500 at 10:30 UTC. 2xx: 94.2%, 3xx: 3.1%, 4xx: 2.4%, 5xx: 0.3%. Avg response time: 145ms.",
        status: "active" as const,
        severity: null,
        source: "prometheus",
        tags: ["http", "requests", "throughput"],
        metadata: JSON.stringify({
          rate: 12000,
          peak: 18500,
          avgResponseTime: "145ms",
        }),
        createdAt: hour(0.1),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "metric" as const,
        title: "Database Connections - 45/200",
        content:
          "Active database connections: 45 out of 200 maximum. Idle connections: 12. Connection pool utilization: 22.5%. Avg query duration: 4.2ms. Transactions/sec: 3,200.",
        status: "active" as const,
        severity: null,
        source: "postgres_exporter",
        tags: ["database", "connections", "pool"],
        metadata: JSON.stringify({
          active: 45,
          idle: 12,
          max: 200,
          tps: 3200,
        }),
        createdAt: hour(0.1),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "metric" as const,
        title: "Queue Depth - 50,847 messages pending",
        content:
          "Total pending messages across all queues: 50,847. Top queue: email-notifications (35,000). Processing rate: 40/min. Estimated drain time: 21 hours at current rate.",
        status: "warning" as const,
        severity: "high",
        source: "rabbitmq_exporter",
        tags: ["queue", "messages", "backlog"],
        metadata: JSON.stringify({
          pending: 50847,
          processingRate: 40,
          drainTime: "21h",
        }),
        createdAt: hour(0.1),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "metric" as const,
        title: "Disk Usage Across Servers",
        content:
          "web-prod-01: /var 89% (warning), / 45%. web-prod-02: / 52%, /var 34%. db-master-01: /data 78%, / 31%. app-staging-01: / 28%. worker-queue-01: / 42%. monitor-01: /var/lib 67%.",
        status: "warning" as const,
        severity: "medium",
        source: "node_exporter",
        tags: ["disk", "storage", "filesystem"],
        metadata: JSON.stringify({ alertServer: "web-prod-01", alertPath: "/var" }),
        createdAt: hour(0.1),
      },

      // === ALERTS ===
      {
        serverId: serverMap["monitor-01"],
        category: "alert" as const,
        title: "CRITICAL: web-prod-01 disk space < 15%",
        content:
          "Firing alert: disk_space_critical on web-prod-01. Filesystem /var at 89% (threshold: 85%). Triggered 2 hours ago. Notification sent to #ops-critical Slack channel and PagerDuty.",
        status: "active" as const,
        severity: "critical",
        source: "alertmanager",
        tags: ["disk", "critical", "firing"],
        metadata: JSON.stringify({
          firedAt: hour(2).toISOString(),
          notified: ["slack", "pagerduty"],
        }),
        createdAt: hour(2),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "alert" as const,
        title: "WARNING: Queue backlog exceeding threshold",
        content:
          "Firing alert: queue_backlog_warning on worker-queue-01. Pending messages: 50,847 (threshold: 10,000). Triggered 30 minutes ago. Root cause: OOM crash of email worker process.",
        status: "active" as const,
        severity: "high",
        source: "alertmanager",
        tags: ["queue", "backlog", "warning"],
        metadata: JSON.stringify({
          firedAt: hour(0.5).toISOString(),
          threshold: 10000,
        }),
        createdAt: hour(0.5),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "alert" as const,
        title: "RESOLVED: Prometheus scrape timeouts",
        content:
          "Previously firing alert: scrape_timeout on prometheus targets. Last fired: 2 hours ago. Resolution: Network routing issue resolved by infrastructure team. Scrape success rate: 100%.",
        status: "completed" as const,
        severity: "info",
        source: "alertmanager",
        tags: ["prometheus", "resolved", "scrape"],
        metadata: JSON.stringify({ resolvedAt: hour(0.5).toISOString() }),
        createdAt: hour(0.5),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "alert" as const,
        title: "WARNING: PostgreSQL replication lag > 30s",
        content:
          "Firing alert: replication_lag on db-master-01. Current lag: 47 seconds (threshold: 30s). Replica: db-replica-01. Impact: Read replicas serving stale data. Possible cause: WAL shipping bottleneck.",
        status: "active" as const,
        severity: "high",
        source: "alertmanager",
        tags: ["postgresql", "replication", "lag"],
        metadata: JSON.stringify({
          lagSeconds: 47,
          threshold: 30,
          replica: "db-replica-01",
        }),
        createdAt: hour(3),
      },

      // === SERVICES ===
      {
        serverId: serverMap["web-prod-01"],
        category: "service" as const,
        title: "Nginx Reverse Proxy Service",
        content:
          "Systemd service: nginx.service. Status: active (running). PID: 1234. Memory: 124MB. Handles SSL termination, static file serving, and reverse proxy to upstream Node.js apps. Auto-restart on failure.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["nginx", "service", "proxy"],
        metadata: JSON.stringify({ pid: 1234, memoryMB: 124 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "service" as const,
        title: "PostgreSQL Database Service",
        content:
          "Systemd service: postgresql@16-main.service. Status: active (running). PID: 5678. Memory: 4.2GB. Uptime: 45 days. Last restart reason: configuration change.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["postgresql", "service", "database"],
        metadata: JSON.stringify({ pid: 5678, memoryMB: 4200, uptimeDays: 45 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "service" as const,
        title: "RabbitMQ Message Broker Service",
        content:
          "Systemd service: rabbitmq-server.service. Status: active (running). PID: 9012. Memory: 1.8GB. Management UI available on port 15672. Clustering: single node.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["rabbitmq", "service", "messaging"],
        metadata: JSON.stringify({ pid: 9012, memoryMB: 1800 }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["monitor-01"],
        category: "service" as const,
        title: "Prometheus Metrics Collection Service",
        content:
          "Systemd service: prometheus.service. Status: degraded. PID: 3456. Memory: 2.1GB. Issue: 2 of 18 scrape targets unreachable. Active time series: 124,847. Storage: 89GB.",
        status: "warning" as const,
        severity: "medium",
        source: "systemd",
        tags: ["prometheus", "service", "metrics"],
        metadata: JSON.stringify({
          pid: 3456,
          memoryMB: 2100,
          activeTargets: 16,
          unreachableTargets: 2,
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["worker-queue-01"],
        category: "service" as const,
        title: "Redis Cache Service",
        content:
          "Systemd service: redis-server.service. Status: active (running). PID: 7890. Memory: 1.3GB/2GB. Evictions: 1,247 (last 24h). Persistence: RDB snapshots every 15min.",
        status: "active" as const,
        severity: null,
        source: "systemd",
        tags: ["redis", "service", "cache"],
        metadata: JSON.stringify({ pid: 7890, memoryMB: 1300 }),
        createdAt: hour(720),
      },

      // === DATABASES ===
      {
        serverId: serverMap["db-master-01"],
        category: "database" as const,
        title: "ecommerce_prod - Main Production Database",
        content:
          "Primary production database. Size: 127GB. Tables: 347. Active connections: 28. Transactions/sec: 2,800. Backup: daily at 02:00 UTC, last backup: 8 hours ago (28GB compressed).",
        status: "active" as const,
        severity: null,
        source: "postgresql",
        tags: ["database", "production", "ecommerce"],
        metadata: JSON.stringify({
          sizeGB: 127,
          tables: 347,
          connections: 28,
          tps: 2800,
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "database" as const,
        title: "analytics_dw - Data Warehouse",
        content:
          "Analytics data warehouse. Size: 89GB. Tables: 1,247 (fact + dimension). Materialized views: 42. ETL pipeline runs every hour. Last ETL: 15 minutes ago. Query avg: 12.3s.",
        status: "active" as const,
        severity: null,
        source: "postgresql",
        tags: ["database", "analytics", "warehouse"],
        metadata: JSON.stringify({
          sizeGB: 89,
          tables: 1247,
          materializedViews: 42,
          avgQueryTime: "12.3s",
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "database" as const,
        title: "sessions_db - Session Store",
        content:
          "User session storage database. Size: 2.3GB. Tables: 4. Active sessions: 12,847. Session TTL: 24 hours. Cleanup job runs every 30 minutes. Connections via PgBouncer.",
        status: "active" as const,
        severity: null,
        source: "postgresql",
        tags: ["database", "sessions", "store"],
        metadata: JSON.stringify({
          sizeGB: 2.3,
          tables: 4,
          activeSessions: 12847,
        }),
        createdAt: hour(720),
      },
      {
        serverId: serverMap["db-master-01"],
        category: "database" as const,
        title: "audit_log_db - Audit Trail Database",
        content:
          "Audit trail and compliance database. Size: 234GB. Tables: 12. Retention: 7 years. Partitioned by month. Current partitions: 84. Write-heavy workload: 1,200 inserts/sec.",
        status: "active" as const,
        severity: null,
        source: "postgresql",
        tags: ["database", "audit", "compliance"],
        metadata: JSON.stringify({
          sizeGB: 234,
          tables: 12,
          partitions: 84,
          insertsPerSec: 1200,
        }),
        createdAt: hour(720),
      },
    ];

    // Insert items in batches of 20
    for (let i = 0; i < items.length; i += 20) {
      const batch = items.slice(i, i + 20);
      await db.insert(searchableItems).values(
        batch.map((item) => ({
          ...item,
          updatedAt: item.createdAt,
        }))
      );
    }

    return NextResponse.json({
      success: true,
      servers: insertedServers.length,
      items: items.length,
      message: `Seeded ${insertedServers.length} servers and ${items.length} searchable items`,
    });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json(
      { error: "Failed to seed data", details: String(error) },
      { status: 500 }
    );
  }
}
