"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import SearchBar from "./SearchBar";
import FilterBar from "./FilterBar";
import ResultsList from "./ResultsList";
import StatsPanel from "./StatsPanel";
import type { SearchResult, StatsData, ServerInfo } from "@/types/search";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("");
  const [serverId, setServerId] = useState("");
  const [status, setStatus] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [stats, setStats] = useState<StatsData | null>(null);
  const [servers, setServers] = useState<ServerInfo[]>([]);
  const [seedStatus, setSeedStatus] = useState<
    "idle" | "seeding" | "done" | "error"
  >("idle");
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch servers and stats on mount
  useEffect(() => {
    fetchServers();
    fetchStats();
  }, []);

  const fetchServers = async () => {
    try {
      const res = await fetch("/api/servers");
      const data = await res.json();
      if (data.servers) setServers(data.servers);
    } catch (err) {
      console.error("Failed to fetch servers:", err);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/stats");
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error("Failed to fetch stats:", err);
    }
  };

  const handleSeed = async () => {
    setSeedStatus("seeding");
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setSeedStatus("done");
        await Promise.all([fetchServers(), fetchStats()]);
      } else {
        setSeedStatus("error");
      }
    } catch (err) {
      console.error("Seed error:", err);
      setSeedStatus("error");
    }
  };

  const performSearch = useCallback(
    async (q: string, cat: string, srv: string, st: string) => {
      if (!q.trim() && !cat && !srv) {
        setResults([]);
        setTotal(0);
        setSearched(false);
        return;
      }

      setLoading(true);
      setSearched(true);

      try {
        const params = new URLSearchParams();
        if (q.trim()) params.set("q", q.trim());
        if (cat) params.set("category", cat);
        if (srv) params.set("serverId", srv);
        if (st) params.set("status", st);
        params.set("limit", "100");

        const res = await fetch(`/api/search?${params.toString()}`);
        const data = await res.json();

        if (data.results) {
          setResults(data.results);
          setTotal(data.total);
        } else {
          setResults([]);
          setTotal(0);
        }
      } catch (err) {
        console.error("Search error:", err);
        setResults([]);
        setTotal(0);
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Debounced search on query/filter changes
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);

    debounceRef.current = setTimeout(() => {
      performSearch(query, category, serverId, status);
    }, 300);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query, category, serverId, status, performSearch]);

  const isEmpty = servers.length === 0 && !stats;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-sm">
                <svg
                  className="w-4 h-4 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
              <div>
                <h1 className="text-sm font-semibold text-slate-900 tracking-tight">
                  Server Search
                </h1>
                <p className="text-[10px] text-slate-500 -mt-0.5">
                  Cross-server unified search
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {servers.length > 0 && (
                <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse-dot" />
                  {servers.filter((s) => s.status === "online").length} of{" "}
                  {servers.length} servers online
                </div>
              )}
              {isEmpty && (
                <button
                  onClick={handleSeed}
                  disabled={seedStatus === "seeding"}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
                >
                  {seedStatus === "seeding" ? (
                    <>
                      <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Seeding...
                    </>
                  ) : (
                    <>
                      <svg
                        className="w-3 h-3"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                        />
                      </svg>
                      Seed Demo Data
                    </>
                  )}
                </button>
              )}
              {seedStatus === "done" && (
                <span className="text-xs text-emerald-600 font-medium">
                  Data seeded!
                </span>
              )}
              {seedStatus === "error" && (
                <span className="text-xs text-red-600 font-medium">
                  Seed failed
                </span>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Search Section */}
        <div className="mb-6">
          <div className="text-center mb-4">
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Search everything across{" "}
              <span className="text-blue-600">all servers</span>
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Logs, containers, apps, programs, documents, configs, metrics,
              alerts, services &amp; databases
            </p>
          </div>
          <SearchBar query={query} onChange={setQuery} />
        </div>

        {/* Filters */}
        <FilterBar
          category={category}
          serverId={serverId}
          status={status}
          servers={servers}
          onCategoryChange={setCategory}
          onServerChange={setServerId}
          onStatusChange={setStatus}
          total={total}
          searched={searched}
        />

        {/* Content */}
        <div className="mt-6 flex gap-6">
          {/* Results */}
          <div className="flex-1 min-w-0">
            <ResultsList
              results={results}
              loading={loading}
              searched={searched}
              query={query}
              total={total}
            />
          </div>

          {/* Stats Sidebar */}
          {stats && (
            <aside className="hidden lg:block w-72 flex-shrink-0">
              <StatsPanel stats={stats} servers={servers} />
            </aside>
          )}
        </div>
      </main>
    </div>
  );
}
