export type ItemCategory =
  | "log"
  | "container"
  | "app"
  | "program"
  | "document"
  | "config"
  | "metric"
  | "alert"
  | "service"
  | "database";

export type ItemStatus =
  | "active"
  | "inactive"
  | "error"
  | "warning"
  | "stopped"
  | "pending"
  | "completed"
  | "failed";

export type ServerStatus =
  | "online"
  | "offline"
  | "maintenance"
  | "degraded";

export interface SearchResult {
  id: number;
  category: ItemCategory;
  title: string;
  content: string | null;
  metadata: Record<string, unknown> | null;
  status: ItemStatus | null;
  severity: string | null;
  source: string | null;
  tags: string[] | null;
  createdAt: string;
  serverId: number;
  serverName: string;
  serverHostname: string;
  serverLocation: string;
}

export interface ServerInfo {
  id: number;
  name: string;
  hostname: string;
  ipAddress: string;
  location: string;
  status: ServerStatus;
  os: string | null;
  tags: string[] | null;
  itemCount: number;
}

export interface StatsData {
  totalItems: number;
  categoryCounts: Record<string, number>;
  statusCounts: Record<string, number>;
  serverCounts: {
    id: number;
    name: string;
    status: ServerStatus;
    count: number;
  }[];
  severityCounts: Record<string, number>;
}

export const CATEGORY_CONFIG: Record<
  ItemCategory,
  { label: string; icon: string; color: string; bgColor: string }
> = {
  log: {
    label: "Logs",
    icon: "📋",
    color: "text-amber-700",
    bgColor: "bg-amber-50 border-amber-200",
  },
  container: {
    label: "Containers",
    icon: "🐳",
    color: "text-blue-700",
    bgColor: "bg-blue-50 border-blue-200",
  },
  app: {
    label: "Applications",
    icon: "🚀",
    color: "text-emerald-700",
    bgColor: "bg-emerald-50 border-emerald-200",
  },
  program: {
    label: "Programs",
    icon: "⚙️",
    color: "text-purple-700",
    bgColor: "bg-purple-50 border-purple-200",
  },
  document: {
    label: "Documents",
    icon: "📄",
    color: "text-sky-700",
    bgColor: "bg-sky-50 border-sky-200",
  },
  config: {
    label: "Configs",
    icon: "🔧",
    color: "text-slate-700",
    bgColor: "bg-slate-100 border-slate-300",
  },
  metric: {
    label: "Metrics",
    icon: "📊",
    color: "text-cyan-700",
    bgColor: "bg-cyan-50 border-cyan-200",
  },
  alert: {
    label: "Alerts",
    icon: "🔔",
    color: "text-red-700",
    bgColor: "bg-red-50 border-red-200",
  },
  service: {
    label: "Services",
    icon: "🔌",
    color: "text-indigo-700",
    bgColor: "bg-indigo-50 border-indigo-200",
  },
  database: {
    label: "Databases",
    icon: "🗄️",
    color: "text-orange-700",
    bgColor: "bg-orange-50 border-orange-200",
  },
};

export const STATUS_CONFIG: Record<
  ItemStatus,
  { label: string; color: string; dotColor: string }
> = {
  active: {
    label: "Active",
    color: "text-emerald-700 bg-emerald-50",
    dotColor: "bg-emerald-400",
  },
  inactive: {
    label: "Inactive",
    color: "text-slate-600 bg-slate-100",
    dotColor: "bg-slate-400",
  },
  error: {
    label: "Error",
    color: "text-red-700 bg-red-50",
    dotColor: "bg-red-400",
  },
  warning: {
    label: "Warning",
    color: "text-amber-700 bg-amber-50",
    dotColor: "bg-amber-400",
  },
  stopped: {
    label: "Stopped",
    color: "text-slate-700 bg-slate-100",
    dotColor: "bg-slate-500",
  },
  pending: {
    label: "Pending",
    color: "text-blue-700 bg-blue-50",
    dotColor: "bg-blue-400",
  },
  completed: {
    label: "Completed",
    color: "text-emerald-700 bg-emerald-50",
    dotColor: "bg-emerald-500",
  },
  failed: {
    label: "Failed",
    color: "text-red-700 bg-red-50",
    dotColor: "bg-red-500",
  },
};

export const SERVER_STATUS_CONFIG: Record<
  ServerStatus,
  { label: string; color: string; dotColor: string }
> = {
  online: {
    label: "Online",
    color: "text-emerald-700 bg-emerald-50",
    dotColor: "bg-emerald-400",
  },
  offline: {
    label: "Offline",
    color: "text-slate-700 bg-slate-100",
    dotColor: "bg-slate-400",
  },
  maintenance: {
    label: "Maintenance",
    color: "text-amber-700 bg-amber-50",
    dotColor: "bg-amber-400",
  },
  degraded: {
    label: "Degraded",
    color: "text-orange-700 bg-orange-50",
    dotColor: "bg-orange-400",
  },
};
